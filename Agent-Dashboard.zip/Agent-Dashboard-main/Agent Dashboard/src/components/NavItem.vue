<template>
  <q-item clickable :to="to" active-class="bg-primary text-white" exact>
    <q-item-section avatar>
      <q-icon :name="icon" />
    </q-item-section>
    <q-item-section>{{ label }}</q-item-section>
  </q-item>
</template>

<script setup lang="ts">
defineProps<{ to: string; icon: string; label: string }>()
</script>
