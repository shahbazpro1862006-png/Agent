<template>
  <div class="row items-center justify-center" style="min-height: 60vh;">
    <q-card bordered class="q-pa-lg" style="max-width: 520px; width: 100%;">
      <div class="text-h6 text-weight-semibold">404 Page Not Found</div>
      <div class="text-body2 text-grey-6 q-mt-sm">The page you requested doesn’t exist.</div>
      <q-btn class="q-mt-md" color="primary" label="Go to Home" to="/dashboard/home" />
    </q-card>
  </div>
</template>
