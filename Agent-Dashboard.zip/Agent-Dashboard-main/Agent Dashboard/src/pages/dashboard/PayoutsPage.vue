<template>
  <q-card bordered class="q-pa-md">
    <div class="text-subtitle1 text-weight-semibold">Payouts (Read-only)</div>
    <div class="text-body2 text-grey-6 q-mt-xs">View payout lifecycle. No approvals in agent.</div>
    <q-banner class="q-mt-md" dense rounded>
      This page is wired in routing/navigation. Replace mock content with your final data views without changing user flows.
    </q-banner>
  </q-card>
</template>
