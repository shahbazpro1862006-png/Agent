<template>
  <q-card bordered class="q-pa-md">
    <div class="text-subtitle1 text-weight-semibold">War Detail</div>
    <div class="text-body2 text-grey-6 q-mt-xs">War scoreboard, feed, rules.</div>
    <q-banner class="q-mt-md" dense rounded>
      This page is wired in routing/navigation. Replace mock content with your final data views without changing user flows.
    </q-banner>
  </q-card>
</template>
